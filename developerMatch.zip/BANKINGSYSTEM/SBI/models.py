from django.db import models
from django.contrib.auth.models import User

from django.db import models
from django.utils import timezone
class ExperienceLevel(models.Model):
    level = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return self.level


class Skill(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class InterestArea(models.Model):
    description = models.CharField(max_length=255)

    def __str__(self):
        return self.description

class EmployeeDetails(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=100, null=True)
    last_name = models.CharField(max_length=100, null=True)
    email = models.EmailField(max_length=100, null=True)
    experience_level = models.ForeignKey(
        ExperienceLevel,
        on_delete=models.CASCADE,
        default=1  # Assuming '1' is the ID of your 'Beginner' level
    )
    skills = models.ManyToManyField(Skill)
    interest_areas = models.ManyToManyField(InterestArea)

    def __str__(self):
        return self.user.username


from django.db import models
from django.contrib.auth.models import User

from django.db import models
from django.contrib.auth.models import User

class ChatRoom(models.Model):
    name = models.CharField(max_length=255, blank=True, null=True)  # Optional room name
    participants = models.ManyToManyField(User, related_name='chatrooms')
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"ChatRoom {self.id} - Participants: {', '.join([user.username for user in self.participants.all()])}"


class ChatMessage(models.Model):
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_messages')
    recipient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='received_messages',default=1)
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    def __str__(self):
        return f'Message from {self.sender.username} to {self.recipient.username} at {self.timestamp}'
class Transactions(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    balance=models.IntegerField()
    def _str_(self):
        return self.balance


class Loans(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    Name=models.CharField(max_length=50)
    Mobile=models.IntegerField()
    Email=models.CharField(max_length=100)
    Proof=models.CharField(max_length=50)


    def _str_(self):
        return self.Proof


class Account(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    Name=models.CharField(max_length=50)
    Account_balance=models.IntegerField()

    def _str_(self):
        return self.Account_balance

class Docc(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    File=models.FileField()

    def _str_(self):
        return self.File







# Create your models here.
