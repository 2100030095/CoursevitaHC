from django.contrib import admin
from django.db import models
from .models import EmployeeDetails, Transactions, Loans, Docc, Account

# Register EmployeeDetails
@admin.register(EmployeeDetails)
class EmployeeDetailsAdmin(admin.ModelAdmin):
    list_display = ['user', 'first_name', 'last_name', 'email',  'experience_level']
    # Exclude 'skills' and 'interest_areas' as they are ManyToManyFields

# Register Transactions
@admin.register(Transactions)
class TransactionsAdmin(admin.ModelAdmin):
    list_display = [field.name for field in Transactions._meta.get_fields() if not isinstance(field, models.ManyToManyField)]

# Register Loans
@admin.register(Loans)
class LoansAdmin(admin.ModelAdmin):
    list_display = [field.name for field in Loans._meta.get_fields() if not isinstance(field, models.ManyToManyField)]

# Register Docc
@admin.register(Docc)
class DoccAdmin(admin.ModelAdmin):
    list_display = [field.name for field in Docc._meta.get_fields() if not isinstance(field, models.ManyToManyField)]

# Register Account
@admin.register(Account)
class AccountAdmin(admin.ModelAdmin):
    list_display = [field.name for field in Account._meta.get_fields() if not isinstance(field, models.ManyToManyField)]
