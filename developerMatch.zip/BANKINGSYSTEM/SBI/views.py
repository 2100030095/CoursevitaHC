from importlib.resources import _

from django.contrib.auth.forms import PasswordResetForm
from django.contrib.auth.tokens import default_token_generator
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render,redirect
from django.template import loader
from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_protect
from django.views.generic.edit import FormView

from .forms import StudentForm,MyForm
from .functions import handle_uploaded_file
from .models import *
from django.contrib.auth import login ,logout,authenticate


# Create your views here.
def test(request):
    form=MyForm()
    return render(request,'login.html',{'form':form})
def index(request):
    return render(request,'index.html')


from django.shortcuts import render, redirect
from .models import EmployeeDetails, ExperienceLevel, Skill, InterestArea
from django.contrib.auth.models import User
from django.contrib import messages

def employee_signup_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['pwd']
        first_name = request.POST['firstname']
        last_name = request.POST['lastname']
        email = request.POST['email']
        experience_level_name = request.POST['experience']
        skills_list = request.POST['skills'].split(',')
        interests = request.POST['interests'].split(',')

        # Create or get the experience level
        experience_level, created = ExperienceLevel.objects.get_or_create(level=experience_level_name)

        # Create a new user
        user = User.objects.create_user(username=username, password=password, email=email)
        user.first_name = first_name
        user.last_name = last_name
        user.save()

        # Create EmployeeDetails
        employee_details = EmployeeDetails.objects.create(
            user=user,
            first_name=first_name,
            last_name=last_name,
            email=email,
            experience_level=experience_level
        )

        # Create or get skills
        for skill in skills_list:
            skill_obj, _ = Skill.objects.get_or_create(name=skill.strip())
            employee_details.skills.add(skill_obj)

        # Create or get interest areas
        for interest in interests:
            interest_obj, _ = InterestArea.objects.get_or_create(description=interest.strip())
            employee_details.interest_areas.add(interest_obj)

        messages.success(request, 'Signup Successful')
        return redirect('login_user')  # Redirect to the login page

    return render(request,'registration.html',locals())

def registration(request):
    error = ""
    if request.method == 'POST':
        fn = request.POST['firstname']
        ln = request.POST['lastname']
        ec = request.POST['empcode']
        ac = request.POST['acctype']
        gender = request.POST['Gender']
        em = request.POST['email']
        pwd = request.POST['pwd']
        try:
            user = User.objects.create_user(first_name=fn,last_name=ln,username=em,password=pwd)
            employee=EmployeeDetails.objects.create(user=user,Mobile_Number=ec,Name=ln,Email=em,Account=ac,gender=gender)
            tr=Transactions.objects.create(user=user,balance=500)
            ac=Account.objects.create(user=user,Name=ln,Account_balance=500)
            l=Loans.objects.create(user=user)

            error = "no"

        except:
            error = "yes"
    return render(request,'registration.html',locals())

def login_user(request):
    error = ""
    if request.method == 'POST':
        form=MyForm(request.POST)
        if form.is_valid():
            u = request.POST['email']
            p = request.POST['password']
            user = authenticate(username=u, password=p)
            if user:
                login(request, user)
                error = "no"
            else:
                error = "yes"

    return render(request, 'login.html', locals())


from django.shortcuts import render
from .models import EmployeeDetails, Skill, InterestArea


from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from .models import EmployeeDetails
from django.db.models import Q
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ObjectDoesNotExist

@login_required
def dashboard(request):
    try:
        user_details = EmployeeDetails.objects.select_related('experience_level').get(user=request.user)

        # Create a Q object for filtering matched developers
        match_criteria = Q(experience_level=user_details.experience_level)

        # Further filter by matching skills or interests if they exist
        if user_details.skills.exists():
            match_criteria |= Q(skills__in=user_details.skills.all())
        if user_details.interest_areas.exists():
            match_criteria |= Q(interest_areas__in=user_details.interest_areas.all())
        unread_messages = ChatMessage.objects.filter(recipient=request.user, is_read=False).order_by('timestamp')

        # Optionally mark messages as read (if you want to track read/unread status)
        for message in unread_messages:
            message.is_read = True
            message.save()
        # Fetch matched developers excluding the current user
        matched_developers = EmployeeDetails.objects.filter(match_criteria).exclude(user=request.user).distinct()

        messages = {}
        for developer in matched_developers:
            # Combine the messages for easy access
            user_messages = ChatMessage.objects.filter(
                sender=request.user, recipient=developer.user
            ).union(
                ChatMessage.objects.filter(sender=developer.user, recipient=request.user)
            ).order_by('timestamp')
            messages[developer.id] = list(user_messages)  # Convert QuerySet to list

        # Fetch chat rooms (if you want to keep this logic for future use)
        chat_rooms = ChatRoom.objects.filter(participants=request.user)

        return render(request, 'dashboard.html', {
            'user_details': user_details,
            'matched_developers': matched_developers,
            'chat_rooms': chat_rooms,
            'unread_messages': unread_messages,
            'messages': messages  # Pass messages as is
        })
    except ObjectDoesNotExist:
        # Handle the case where the EmployeeDetails does not exist for the user
        return render(request, 'error.html', {'message': 'User details not found.'})


from django.shortcuts import render, redirect, get_object_or_404
from .models import ChatRoom, EmployeeDetails
from django.contrib.auth.models import User


def create_or_get_chat_room(request, matched_user_id):
    # Get the current logged-in user
    user = request.user
    matched_user = get_object_or_404(User, id=matched_user_id)

    # Check if a chat room already exists between the users
    chat_room = ChatRoom.objects.filter(participants__in=[user]).filter(participants__in=[matched_user]).distinct()

    if chat_room.exists():
        # If a chat room already exists, redirect to the existing room
        room = chat_room.first()
    else:
        # If no chat room exists, create a new one
        room = ChatRoom.objects.create()
        room.participants.add(user, matched_user)  # Add both users as participants
        room.save()

    # Redirect to the chat room
    return redirect('chat_room', room_id=room.id)


from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import ChatRoom, ChatMessage
from django.shortcuts import redirect
from .models import ChatMessage

from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from .models import ChatMessage, EmployeeDetails

# views.py
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.db.models import Q
from .models import ChatMessage

# views.py
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.db.models import Q
from .models import ChatMessage


def send_message(request):
    if request.method == 'POST':
        recipient_id = request.POST.get('recipient_id')
        message_content = request.POST.get('message')
        recipient = User.objects.get(id=recipient_id)

        # Create the message
        ChatMessage.objects.create(
            sender=request.user,
            recipient=recipient,
            message=message_content
        )
        return redirect('dashboard')  # Redirect to the dashboard


def fetch_messages(request, recipient_id):
    recipient = User.objects.get(id=recipient_id)  # Fetch the recipient user
    messages = ChatMessage.objects.filter(
        (Q(sender=request.user) & Q(recipient=recipient)) |
        (Q(sender=recipient) & Q(recipient=request.user))
    ).order_by('timestamp')
    return render(request, 'chat.html', {'messages': messages, 'recipient': recipient})


def get_messages(request, recipient_id):
    messages = ChatMessage.objects.filter(
        Q(sender=request.user, recipient_id=recipient_id) | Q(sender=recipient_id, recipient=request.user)
    ).order_by('timestamp')
    messages_data = [{'sender': msg.sender.username, 'text': msg.message, 'timestamp': msg.timestamp} for msg in messages]
    return JsonResponse({'messages': messages_data})

@login_required
def chat_dashboard(request):
    # Get all chat rooms that the user is a participant of
    chat_rooms = ChatRoom.objects.filter(participants=request.user)
    return render(request, 'chat_dashboard.html', {'chat_rooms': chat_rooms})


from django.shortcuts import get_object_or_404

@login_required
def chat_room(request, room_id):
    room = get_object_or_404(ChatRoom, id=room_id)  # This will raise a 404 error if room does not exist
    messages = ChatMessage.objects.filter(chat_room=room)  # Get messages for this room

    if request.method == 'POST':
        message_content = request.POST['message']
        ChatMessage.objects.create(chat_room=room, sender=request.user, message=message_content)
        return redirect('chat_room', room_id=room.id)  # Redirect to the same room to see the new message

    return render(request, 'chat_room.html', {'room': room, 'messages': messages})

@login_required
def create_chat_room(request):
    if request.method == 'POST':
        room_name = request.POST.get('room_name')
        if room_name:
            new_room = ChatRoom.objects.create(name=room_name)
            return redirect('chat_room', room_id=new_room.id)  # Redirect to the new chat room
    return render(request, 'create_chat_room.html')  # Display the form


def base(request):
    if not request.user.is_authenticated:
        return redirect('login_user')
    user=request.user
    ac = Account.objects.get(user=user)
    #id=Transactions.objects.get(user=user)
    employee=EmployeeDetails.objects.get(user=user)
    return render(request,'base.html')

def withdraw(request):
    if not request.user.is_authenticated:
        return redirect('login_user')

    error = ""

    user = request.user

    if request.method == "POST":
        amt = request.POST['with']
        id=Transactions.objects.create(user=user,balance=amt)
        ac=Account.objects.get(user=user)
        a=ac.Account_balance
        c=a-int(id.balance)
        ac.Account_balance=c
        ac.save()
        #transaction=Transactions.objects.get(id=id)




        try:
            transaction.save()
            error="no"

        except:
            error="yes"
    return render(request,'withdraw.html',locals())

def deposite(request):
    if not request.user.is_authenticated:
        return redirect('login_user')
    error=""
    user = request.user
    mydata = Transactions.objects.filter(user_id=request.user).values()


    #a=id.balance
    if request.method=="POST":
        amt = request.POST['dep']
        id = Transactions.objects.create(user=user, balance=amt)
        ac = Account.objects.get(user=user)
        a = ac.Account_balance
        c = a + int(id.balance)
        ac.Account_balance = c
        ac.save()
        acc=Account.objects.get(user=user)
        try:

            #Transactions.objects.create(user=user,balance=c)

            error = "no"

        except:
            error = "yes"

    return render(request,'deposite.html')

def transaction(request):

    if not request.user.is_authenticated:
        return redirect('login_user')

    #user = request.user
    user=request.user
    ac = Account.objects.filter(user_id=user).values()
    mydata = Transactions.objects.filter(user_id=user).values()
    template = loader.get_template('transaction.html')
    context = {
        'mydata': mydata,
        'ac':ac,
        }
    return HttpResponse(template.render(context, request))

def profile(request):
    if not request.user.is_authenticated:
        return redirect('login_user')

    error = ""
    user = request.user
    employee = EmployeeDetails.objects.get(user=user)
    ac = Account.objects.get(user=user)


    if request.method == "POST":
        fn = request.POST['firstname']
        ln = request.POST['lastname']
        ec = request.POST['empcode']
        em = request.POST['email']
        Acc = request.POST['acctype']

        gender = request.POST['gender']

        employee.user.first_name = fn
        employee.user.last_name = ln
        employee.Name=ln
        employee.Mobile_Number = ec
        employee.Email = em
        employee.Account=Acc
        employee.gender = gender


        try:
            employee.save()
            employee.user.save()
            error="no"

        except:
            error="yes"
    return render(request,'profile.html',locals())

def change_pass(request):
    if not request.user.is_authenticated:
        return redirect('login_user')

    error = ""
    user = request.user
    if request.method == "POST":
        c = request.POST['currentpassword']
        n = request.POST['newpassword']
        try:
            if user.check_password(c):
                user.set_password(n)
                user.save()
                error="no"
            else :
                error="not"

        except:
            error="yes"
    return render(request,'change_pass.html',locals())

def logout(request):


    return HttpResponseRedirect('test')

def admin_login(request):
    error = ""
    if request.method == 'POST':
        u = request.POST['username']
        p = request.POST['pwd']
        user = authenticate(username=u,password=p)
        try:
            if user.is_staff:
               login(request,user)
               error="no"
            else:
               error="yes"

        except :
            error="yes"
    return render(request,'admin_login.html',locals())
def admin_home(request):
    return render(request,'admin_home.html')


def change_passwordadmin(request):

    error = ""

    user = request.user
    if request.method == "POST":
        c = request.POST['currentpassword']
        n = request.POST['newpassword']
        try:
            if user.check_password(c):

                user.save()
                error = "no"
            else:
                error = "not"

        except:
            error = "yes"
    return render(request, 'change_passwordadmin.html', locals())

def loans(request):
    if not request.user.is_authenticated:
        return redirect('login_user')
    return render(request,'loans.html')

def cards(request):
    if not request.user.is_authenticated:
        return redirect('login_user')
    return render(request,'cards.html')

def apply_loan(request):
    if not request.user.is_authenticated:
        return redirect('login_user')
    user= request.user
    if request.method == 'POST':
        student = StudentForm(request.POST, request.FILES)
        if student.is_valid():
            file=request.FILES['file']
            handle_uploaded_file(request.FILES['file'])
            Docc.objects.create(user=user,File=file)
            return HttpResponse("File uploaded successfuly","base") and redirect('base')
    else:
        student = StudentForm()
        return render(request,"apply_loan.html",{'form':student})

def apply(request):

    error = ""
    if request.method == 'POST':
        fn = request.POST['firstname']
        ln = request.POST['lastname']
        ec = request.POST['empcode']
        em = request.POST['email']
        prf = request.POST['proof']
        ltype = request.POST['ltype']
        user = request.user
        if Loans.objects.get(user=user):
            l=Loans.objects.get(user=user)
            l.Name=ln
            l.Mobile=ec
            l.Email=em
            l.Proof=prf
            error="no"
            l.save()
        else:

            try:

                loan=Loans.objects.create(user=user,Name=ln,Mobile=ec,Email=em,Proof=prf)

                error = "no"

            except:
                error = "yes"
    return render(request,'apply.html',locals())

def transfer(request):
    if not request.user.is_authenticated:
        return redirect('login_user')
    error=""
    user = request.user
    mydata = Transactions.objects.filter(user_id=request.user).values()


    #a=id.balance
    if request.method=="POST":
        tr=request.POST['em']
        amt = request.POST['transfer']
        id = Transactions.objects.create(user=user, balance=amt)
        u=EmployeeDetails.objects.get(Email=tr)
        u_id=u.user_id
        ac = Account.objects.get(user=user)
        trto=Account.objects.get(user=u_id)
        ta=trto.Account_balance
        a = ac.Account_balance
        c = a - int(id.balance)
        d=ta+ int(id.balance)
        ac.Account_balance = c
        trto.Account_balance=d
        trto.save()
        ac.save()
        acc=Account.objects.get(user=user)
        try:

            #Transactions.objects.create(user=user,balance=c)

            error = "no"

        except:
            error = "yes"

    return render(request,'transfer.html')

class PasswordContextMixin:
    extra_context = None

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update({
            'title':self.title,
            **(self.extra_context or {})
        })
        return context

class PasswordResetView(PasswordContextMixin, FormView):
    email_template_name = 'registration/password_reset_email.html'
    extra_email_context = None
    form_class = PasswordResetForm
    form_email = 'chsatish7095@gmail.com'
    html_email_template_name = None
    subject_template_name = 'registration/password_reset_subject.html'
    success_url = reverse_lazy('password_reset_done')
    template_name = 'registration/password_reset_form.html'
    title = _('Password reset')
    token_generator = default_token_generator

    @method_decorator(csrf_protect)
    def dispatch(self,*args, **kwargs):
        return super().dispatch(*args, **kwargs)




