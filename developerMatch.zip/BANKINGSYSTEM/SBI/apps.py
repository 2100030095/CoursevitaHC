from django.apps import AppConfig


class SbiConfig(AppConfig):
    name = 'SBI'
